export const dummyTraces = [
  { id: 'trace-1', name: 'User Login', timestamp: '2025-08-05 14:33' },
  { id: 'trace-2', name: 'Generate Report', timestamp: '2025-08-05 15:12' },
  { id: 'trace-3', name: 'Chat Prompt', timestamp: '2025-08-06 09:45' },
  { id: 'trace-4', name: 'Summary Generation', timestamp: '2025-08-06 10:20' },
  { id: 'trace-5', name: 'PDF Upload', timestamp: '2025-08-06 11:00' },
];
