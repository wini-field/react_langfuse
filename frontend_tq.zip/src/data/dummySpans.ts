export const dummySpans = [
  {
    id: 'span-1',
    traceId: 'trace-1',
    name: 'DB Query',
    duration: '120ms',
    timestamp: '2025-08-06 14:30',
    description: '사용자로부터 입력을 받는 단계입니다.',
  },
  {
    id: 'span-2',
    traceId: 'trace-1',
    name: 'Auth Check',
    duration: '50ms',
    timestamp: '2025-08-06 14:31',
    description: 'test test test',
  },
  {
    id: 'span-3',
    traceId: 'trace-2',
    name: 'API Call',
    duration: '200ms',
    timestamp: '2025-08-05 15:15',
    description: 'dnlslxpr',
  },
];
