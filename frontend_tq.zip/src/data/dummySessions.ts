export const dummySessions = [
  {
    id: 'session-1',
    traceId: 'trace-1',
    user: 'user123',
    status: 'active',
    startedAt: '2025-08-06 14:20',
  },
  {
    id: 'session-2',
    traceId: 'trace-2',
    user: 'admin456',
    status: 'ended',
    startedAt: '2025-08-05 15:00',
  },
];
